    <!-- Footer Start -->
    <div class="container-fluid footer pt-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-5 col-md-6">
                    <h1 class="mb-4">
                        <!-- <img class="img-fluid" src="#" alt="" /> -->
                        Medi <span>Portal</span>
                    </h1>
                    <p>
                        <i class="fa fa-map-marker-alt me-3"></i>123, Lorem ipsum dolor sit amet, <br> consectetur adipisicing, <br> Australia
                    </p>
                    <p><i class="fa fa-phone-alt me-3"></i>+61 4 123 45678</p>
                    <p><i class="fa fa-envelope me-3"></i>info@mediportal.au</p>

                </div>
                <div class="col-lg-4 col-md-6">
                    <h5 class="mb-4">Quick Links</h5>
                    <a class="btn btn-link" href="">For Providers</a>
                    <a class="btn btn-link" href="">About Us</a>
                    <a class="btn btn-link" href="">For Clinics</a>
                    <a class="btn btn-link" href="">For Doctors</a>
                    <a class="btn btn-link" href="">Contact Us</a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h5 class="mb-4">Social Media Links</h5>
                    <a class="mb-1 btn btn-social" href=""><i class="fab fa-facebook-f me-3"></i> Facebook</a>
                    <a class="mb-1 btn btn-social" href=""><i class="fab fa-twitter me-2"></i> Twitter</a>
                    <a class="mb-0 btn btn-social" href=""><i class="fab fa-linkedin-in me-2"></i> Linkedin</a>
                </div>

            </div>
        </div>
        <div class="container-fluid copyright  bg-light">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                        &copy; 2022 Medi Portal, All Right Reserved. Site By <a href="#" target="_blank">Xiteb</a>
                    </div>
                    <div class="col-md-6 text-center text-md-end">

                        <a class="me-3" href="#" target="_blank">Privacy Policy</a> | <a class="ms-3" href="#" target="_blank">Terms and Conditions</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js" integrity="sha384-ODmDIVzN+pFdexxHEHFBQH3/9/vQ9uori45z4JjnFsRydbmQbmL5t1tQ0culUzyK" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js" integrity="sha512-Eak/29OTpb36LLo2r47IpVzPBLXnAMPAVypbSZiZ4Qkf8p/7S/XRG5xp7OKWPPYfJT6metI+IORkR5G8F900+g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js" integrity="sha512-0QbL0ph8Tc8g5bLhfVzSqxe9GERORsKhIn1IrpxDAgUsbBGz/V7iSav2zzW325XGd1OMLdL4UiqRJj702IeqnQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js" integrity="sha512-CEiA+78TpP9KAIPzqBvxUv8hy41jyI3f2uHi7DGp/Y/Ka973qgSdybNegWFciqh6GrN2UePx2KkflnQUbUhNIA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/countup.js/2.3.2/countUp.min.js" integrity="sha512-qPQega4nO7+N8XzGLxc9xnbJQMOZ3Fury2rBGQPDBJYOZaX71sFj0rBJws8KFrlSRI+7FYkVBsoOFTSME+xlaA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script> -->

	 <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.25.0/moment.min.js" integrity="sha512-f6KXhRr/NS4Ju4zzjeiWcPBrWbISiIGGJHB/ga9/4sABJv1/iXUpQ2PLe+bCk5Eg1dHC//UGWe69htuLzrxRCg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

	 <script src="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.39.0/js/tempusdominus-bootstrap-4.min.js" integrity="sha512-k6/Bkb8Fxf/c1Tkyl39yJwcOZ1P4cRrJu77p83zJjN2Z55prbFHxPs9vN7q3l3+tSMGPDdoH51AEU8Vgo1cgAA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

	 <script src="https://cdnjs.cloudflare.com/ajax/libs/mhayes-twentytwenty/1.0.0/js/jquery.twentytwenty.min.js" integrity="sha512-GPLeok4pmABjbz8dF6i4cqao9fhF9LE5X4rI0ORBe2YqbZmaqdSiM7g4oO+CEy99SxZV6memnoKANwopFr6Z6g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
 
    <!-- Template Javascript -->
    <script src="js/main.js"></script>
    </body>

    </html>