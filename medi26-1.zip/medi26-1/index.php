<?php include('inc/header.php'); ?>

<!-- Carousel Start -->
<div class="container-fluid p-0 wow fadeIn" data-wow-delay="0.1s">
  <div id="header-carousel" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img class="w-100" src="img/carousel-1.jpg" alt="Image" />
        <div class="carousel-caption">
          <div class="container">
            <div class="row">
              <div class="col-12 col-lg-6">
                <h1 class="title mb-4 animated slideInDown">
                  Lorem Ipsum is simply dummy text
                </h1>
                <p class="mb-5">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                </p>
                <a href="" class="btn btn-primary">Read More</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="carousel-item">
        <img class="w-100" src="img/carousel-1.jpg" alt="Image" />
        <div class="carousel-caption">
          <div class="container">
            <div class="row">
              <div class="col-12 col-lg-6">
                <h1 class="title mb-4 animated slideInDown">
                  Lorem Ipsum is simply dummy text
                </h1>
                <p class="mb-5">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                </p>
                <a href="" class="btn btn-primary">Read More</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#header-carousel" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#header-carousel" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
</div>
<!-- Carousel End -->

<!-- Service Start -->
<div class="container-xxl bg-light py-5">
  <div class="container">
    <div class="text-center mx-auto">
      <h1 class="main-title mb-5">
        Features
      </h1>
    </div>
    <div class="row">
      <div id="tab-view" class="col-xs-12 ">
        <nav>
          <div class="nav nav-tabs justify-content-center" id="nav-tab" role="tablist">
            <a class="nav-link active" id="nav-clinics-tab" data-bs-toggle="tab" data-bs-target="#nav-clinics" role="tab" aria-controls="nav-clinics" aria-selected="true">For Clinics</a>
            <a class="nav-link" id="nav-doctors-tab" data-bs-toggle="tab" data-bs-target="#nav-doctors" role="tab" aria-controls="nav-doctors" aria-selected="false">For Doctors</a>
          </div>
        </nav>
        <div class="tab-content" id="nav-tabContent">
          <div class="tab-pane fade show active" id="nav-clinics" role="tabpanel" aria-labelledby="nav-clinics-tab" tabindex="0">
            <div class="row g-4 justify-content-center">
              <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="service-item text-center h-100 p-5">
                  <div class="service-icon bg-primary rounded-circle mb-4">
                    <img class="img-fluid" src="img/icon/icon-10-light.png" alt="" />
                  </div>
                  <h4 class="mb-4">Lorem ipsum dolor sit</h4>
                  <p class="mb-4">
                    Aliqu diam amet eos erat ipsum et lorem et sit, sed stet lorem
                    sit clita duo justo erat amet
                  </p>
                  <a class="btn btn-light px-3" href="">Read More</a>
                </div>
              </div>
              <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                <div class="service-item text-center h-100 p-5">
                  <div class="service-icon bg-primary rounded-circle mb-4">
                    <img class="img-fluid" src="img/icon/icon-01-light.png" alt="" />
                  </div>
                  <h4 class="mb-4">Lorem ipsum dolor sit</h4>
                  <p class="mb-4">
                    Aliqu diam amet eos erat ipsum et lorem et sit, sed stet lorem
                    sit clita duo justo erat amet
                  </p>
                  <a class="btn btn-light px-3" href="">Read More</a>
                </div>
              </div>
              <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="service-item text-center h-100 p-5">
                  <div class="service-icon bg-primary rounded-circle mb-4">
                    <img class="img-fluid" src="img/icon/icon-05-light.png" alt="" />
                  </div>
                  <h4 class="mb-4">Lorem ipsum dolor sit</h4>
                  <p class="mb-4">
                    Aliqu diam amet eos erat ipsum et lorem et sit, sed stet lorem
                    sit clita duo justo erat amet
                  </p>
                  <a class="btn btn-light px-3" href="">Read More</a>
                </div>
              </div>
              <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="service-item text-center h-100 p-5">
                  <div class="service-icon bg-primary rounded-circle mb-4">
                    <img class="img-fluid" src="img/icon/icon-08-light.png" alt="" />
                  </div>
                  <h4 class="mb-4">Lorem ipsum dolor sit</h4>
                  <p class="mb-4">
                    Aliqu diam amet eos erat ipsum et lorem et sit, sed stet lorem
                    sit clita duo justo erat amet
                  </p>
                  <a class="btn btn-light px-3" href="">Read More</a>
                </div>
              </div>
              <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                <div class="service-item text-center h-100 p-5">
                  <div class="service-icon bg-primary rounded-circle mb-4">
                    <img class="img-fluid" src="img/icon/icon-07-light.png" alt="" />
                  </div>
                  <h4 class="mb-4">Lorem ipsum dolor sit</h4>
                  <p class="mb-4">
                    Aliqu diam amet eos erat ipsum et lorem et sit, sed stet lorem
                    sit clita duo justo erat amet
                  </p>
                  <a class="btn btn-light px-3" href="">Read More</a>
                </div>
              </div>
              <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="service-item text-center h-100 p-5">
                  <div class="service-icon bg-primary rounded-circle mb-4">
                    <img class="img-fluid" src="img/icon/icon-06-light.png" alt="" />
                  </div>
                  <h4 class="mb-4">Lorem ipsum dolor sit</h4>
                  <p class="mb-4">
                    Aliqu diam amet eos erat ipsum et lorem et sit, sed stet lorem
                    sit clita duo justo erat amet
                  </p>
                  <a class="btn btn-light px-3" href="">Read More</a>
                </div>
              </div>
            </div>
          </div>
          <div class="tab-pane fade" id="nav-doctors" role="tabpanel" aria-labelledby="nav-doctors-tab" tabindex="0">
            <div class="row g-4 justify-content-center">
              <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="service-item text-center h-100 p-5">
                  <div class="service-icon bg-primary rounded-circle mb-4">
                    <img class="img-fluid" src="img/icon/icon-10-light.png" alt="" />
                  </div>
                  <h4 class="mb-4">Lorem ipsum dolor sit</h4>
                  <p class="mb-4">
                    Aliqu diam amet eos erat ipsum et lorem et sit, sed stet lorem
                    sit clita duo justo erat amet
                  </p>
                  <a class="btn btn-light px-3" href="">Read More</a>
                </div>
              </div>
              <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                <div class="service-item text-center h-100 p-5">
                  <div class="service-icon bg-primary rounded-circle mb-4">
                    <img class="img-fluid" src="img/icon/icon-01-light.png" alt="" />
                  </div>
                  <h4 class="mb-4">Lorem ipsum dolor sit</h4>
                  <p class="mb-4">
                    Aliqu diam amet eos erat ipsum et lorem et sit, sed stet lorem
                    sit clita duo justo erat amet
                  </p>
                  <a class="btn btn-light px-3" href="">Read More</a>
                </div>
              </div>
              <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="service-item text-center h-100 p-5">
                  <div class="service-icon bg-primary rounded-circle mb-4">
                    <img class="img-fluid" src="img/icon/icon-05-light.png" alt="" />
                  </div>
                  <h4 class="mb-4">Lorem ipsum dolor sit</h4>
                  <p class="mb-4">
                    Aliqu diam amet eos erat ipsum et lorem et sit, sed stet lorem
                    sit clita duo justo erat amet
                  </p>
                  <a class="btn btn-light px-3" href="">Read More</a>
                </div>
              </div>
              <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="service-item text-center h-100 p-5">
                  <div class="service-icon bg-primary rounded-circle mb-4">
                    <img class="img-fluid" src="img/icon/icon-08-light.png" alt="" />
                  </div>
                  <h4 class="mb-4">Lorem ipsum dolor sit</h4>
                  <p class="mb-4">
                    Aliqu diam amet eos erat ipsum et lorem et sit, sed stet lorem
                    sit clita duo justo erat amet
                  </p>
                  <a class="btn btn-light px-3" href="">Read More</a>
                </div>
              </div>
              <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                <div class="service-item text-center h-100 p-5">
                  <div class="service-icon bg-primary rounded-circle mb-4">
                    <img class="img-fluid" src="img/icon/icon-07-light.png" alt="" />
                  </div>
                  <h4 class="mb-4">Lorem ipsum dolor sit</h4>
                  <p class="mb-4">
                    Aliqu diam amet eos erat ipsum et lorem et sit, sed stet lorem
                    sit clita duo justo erat amet
                  </p>
                  <a class="btn btn-light px-3" href="">Read More</a>
                </div>
              </div>
              <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="service-item text-center h-100 p-5">
                  <div class="service-icon bg-primary rounded-circle mb-4">
                    <img class="img-fluid" src="img/icon/icon-06-light.png" alt="" />
                  </div>
                  <h4 class="mb-4">Lorem ipsum dolor sit</h4>
                  <p class="mb-4">
                    Aliqu diam amet eos erat ipsum et lorem et sit, sed stet lorem
                    sit clita duo justo erat amet
                  </p>
                  <a class="btn btn-light px-3" href="">Read More</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Service End -->

<!-- About Start -->
<div class="section">
  <div class="content-wrap py-5" style="position:relative;">

    <div class="container">
      <div class="row align-items-center">

        <div class="col-sm-12 col-md-12 col-lg-7">
          <div class="h-100">
            <h1 class="main-title mb-5">
              Who We Are
            </h1>
            <p class="mb-4">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
            <a href="" class="align-self-start btn btn-primary">Read More</a>
          </div>
        </div>

      </div>
    </div>
    <div class="sideright-img bgi-cover-center" data-background="img/about.jpg" style="background-image: url(&quot;img/about.jpg&quot;);">
      <img src="img/about.jpg" alt="" class="img-fluid">
    </div>
  </div>
</div>
<!-- About End -->

<!-- Facts Start -->
<div class="container-fluid my-5 px-lg-0">
  <div class="container px-lg-0">
    <div class="row g-0 mx-lg-0">
      <div class="col-lg-12 wow fadeIn" data-wow-delay="0.1s">
        <div class="h-100 px-4 ps-lg-0 text-lg-center">
          <h1 class="main-title mb-4">Autralia's #1 helthcare platform</h1>
          <p class="mb-5">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
          </p>
        </div>
      </div>

    </div>
  </div>
</div>
<!-- Facts End -->

<!-- Testimonial Start -->
<div id="test" class="container-xxl py-5 bg-light" style="overflow: hidden;">
  <div class="container">
    <div class="row g-5 d-flex align-items-center">
      <div class="col-lg-3 wow fadeInUp align-items-center" data-wow-delay="0.1s">

        <h1 class="main-title mb-3">Testimonial</h1>
        <p class="mb-4">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
        </p>

      </div>
      <div class="col-lg-9 wow fadeInUp" data-wow-delay="0.5s">
        <div class="owl-carousel testimonial-carousel">
          <div class="testimonial-item text-left">
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.
            </p>
            <div class="d-flex align-items-center">
              <img class="img-fluid rounded-circle" src="img/testimonial-1.jpg" alt="" />
              <div class="ms-3">
                <h5>Client Name</h5>
                <span>Profession</span>
              </div>
            </div>
          </div>
          <div class="testimonial-item text-left">
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.
            </p>
            <div class="d-flex align-items-center">
              <img class="img-fluid rounded-circle" src="img/testimonial-2.jpg" alt="" />
              <div class="ms-3">
                <h5>Client Name</h5>
                <span>Profession</span>
              </div>
            </div>
          </div>
          <div class="testimonial-item text-left">
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.
            </p>
            <div class="d-flex align-items-center">
              <img class="img-fluid rounded-circle" src="img/testimonial-3.jpg" alt="" />
              <div class="ms-3">
                <h5>Client Name</h5>
                <span>Profession</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Testimonial End -->

<!-- CTA Start -->
<div class="container-fluid py-5 wow fadeIn" data-wow-delay="0.1s" style="background-color:#3D5488; background-image:url('./img/bg.png');background-position: right;
    background-repeat: no-repeat;
    background-size: contain;">
  <div class="container py-5">
    <div class="row g-5">
      <div class="col-lg-7 wow fadeIn" data-wow-delay="0.3s">
        <h1 class="display-6 text-white mb-5">
          Get started with a free listing today
        </h1>
        <p class="text-white mb-5">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
        </p>
        <a href="" class="align-self-start btn btn-white">Read More</a>
      </div>

    </div>
  </div>
</div>
<!-- CTA End -->

<!-- Contact Form -->
<div class="section">
  <div class="content-wrap" style="position:relative;">
    <div class="sideleft-img">
      <img src="img/contact.jpg" alt="" class="img-fluid">
    </div>

    <div class="container">
      <div class="row">
        <div class="col-lg-7 py-5" style="margin-left:40%;">
          <h1 class="main-title">
            Contact Us
          </h1>
          <div class="p-0">
            <form>
              <div class="row g-3">
                <div class="form-group col-md-6">
                  <label for="name">Name</label>
                  <input type="text" class="form-control" id="inputName">
                </div>
                <div class="form-group col-md-6">
                  <label for="inputEmail4">Email</label>
                  <input type="email" class="form-control" id="inputEmail4">
                </div>

                <div class="form-group col-md-6">
                  <label for="inputState">Service</label>
                  <select id="inputState" class="form-control">
                    <option selected>Select Type</option>
                    <option>...</option>
                    <option>...</option>
                    <option>...</option>
                  </select>
                </div>
                <div class="form-group col-md-6">
                  <label for="inputEmail4">Lorem</label>
                  <input type="text" class="form-control" id="inputEmail4">
                </div>
                <div class="form-group col-12">
                  <label for="message">Message</label>
                  <textarea class="form-control" id="message" style="height: 80px"></textarea>
                </div>
                <div class="col-md-12" style="text-align: right;">
                  <a class="btn btn-primary px-5" type="submit">
                    Send
                  </a>
                </div>
              </div>

            </form>
          </div>
        </div>

      </div>
    </div>

  </div>
</div>
<!-- Contact Form End -->

<!-- Client Logos -->
<div class="container-xxl bg-light">
  <div class="container">
    <div class="row">
      <div class="brand-carousel owl-carousel py-5">
        <div class="single-logo">
          <img src="img/clients/1.png" alt="">
        </div>
        <div class="single-logo">
          <img src="img/clients/2.png" alt="">
        </div>
        <div class="single-logo">
          <img src="img/clients/3.png" alt="">
        </div>
        <div class="single-logo">
          <img src="img/clients/4.png" alt="">
        </div>
        <div class="single-logo">
          <img src="img/clients/5.png" alt="">
        </div>
        <div class="single-logo">
          <img src="img/clients/6.png" alt="">
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Client Logos End-->

<?php include('inc/footer.php'); ?>